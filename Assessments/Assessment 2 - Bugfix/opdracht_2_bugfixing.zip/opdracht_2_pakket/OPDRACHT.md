# Opdracht 2: Bugfixing & Debugging - Starter Pakket

## 🎯 Jouw Opdracht

Er zitten meerdere bugs in deze Laravel-applicatie. Jouw taak is om deze te vinden, analyseren en oplossen.

### Wat moet je doen?

1. Installeer de applicatie en test alle functionaliteiten
2. Identificeer de bugs (er zitten er minstens 3!)
3. Analyseer de oorzaak van elke bug
4. Los de bugs op
5. Documenteer je proces

### Wat zit er al in dit pakket?

- ✅ Laravel 12 volledig werkend
- ✅ Tailwind CSS geconfigureerd
- ✅ 3 pagina's: Home, Over Ons, Belangrijke Gegevens
- ✅ Basic authentication (login/logout)
- ✅ Test gebruiker: jd@maascollege.nl / MijnDevelopmentOpdracht0@!
- ❌ Verschillende bugs die opgelost moeten worden

## 🚀 Aan de slag

1. Volg de installatie instructies in README.md
2. Start de applicatie: `php artisan serve`
3. Login met de testgebruiker
4. Test alle pagina's grondig
5. Let op foutmeldingen, vreemde gedrag, en performance issues

## 🐛 Hints over de bugs

We geven je geen exacte locatie, maar hier zijn wat hints:

### Bug Type 1: Logic Error
Er is iets mis met de weergave van gebruikersstatus. Kijk goed naar wat "Actief" en "Niet Actief" betekent...

### Bug Type 2: Performance Issue
De pagina "Belangrijke Gegevens" kan traag zijn. Check de database queries. Hoeveel queries worden er uitgevoerd?

### Bug Type 3: Code Organization
Database queries horen niet in views thuis. Dit is niet alleen een best practice kwestie, maar kan ook tot problemen leiden.

## 🛠️ Debugging Tools

### Laravel Debug Bar (optioneel te installeren)
```bash
composer require barryvdh/laravel-debugbar --dev
```

### Laravel Telescope (optioneel te installeren)
```bash
composer require laravel/telescope --dev
php artisan telescope:install
php artisan migrate
```

### Native Laravel Tools
```php
// In je code:
dd($variabele); // Dump and die
dump($variabele); // Dump en doorgaan

// Query logging
\DB::enableQueryLog();
// ... je queries ...
dd(\DB::getQueryLog());

// Laravel Log
\Log::info('Debug info', ['data' => $someData]);
```

### Browser DevTools
- Network tab: Check response times
- Console: Check for JavaScript errors

## ✅ Wat verwachten we?

### 1. Werkende applicatie
Alle bugs moeten opgelost zijn en de applicatie moet correct functioneren.

### 2. Documentatie (in README of apart document)
Voor elke bug:
- **Wat was de bug?** (korte beschrijving + screenshot/error indien mogelijk)
- **Wat was de oorzaak?** (technische uitleg)
- **Hoe heb je het opgelost?** (wat heb je veranderd?)
- **Hoe heb je het getest?** (hoe weet je dat het werkt?)
- **Welke debugging technieken heb je gebruikt?** (dd(), Log, Debugbar, etc.)

### 3. Git Commits
Maak duidelijke commits per bug fix:
```bash
git commit -m "fix: correct user status logic in data view"
git commit -m "perf: resolve N+1 query issue in data page"
git commit -m "refactor: move database queries from view to controller"
```

## 📝 Tips voor Debugging

1. **Start met reproduceren:** Zorg dat je de bug consistent kunt triggeren
2. **Isoleer het probleem:** Waar precies gaat het mis?
3. **Check de logs:** `storage/logs/laravel.log`
4. **Use dd() strategisch:** Dump variabelen op cruciale punten
5. **Test incrementeel:** Fix één ding tegelijk
6. **Denk aan edge cases:** Test verschillende scenario's

## 🎓 Laravel Debugging Resources

- [Laravel Logging](https://laravel.com/docs/logging)
- [Database Query Debugging](https://laravel.com/docs/queries#debugging)
- [Eloquent N+1 Problem](https://laravel.com/docs/eloquent-relationships#eager-loading)
- [Laravel Best Practices](https://github.com/alexeymezenin/laravel-best-practices)

## 📤 Inleveren

1. Git repository met je fixes
2. README.md of BUGFIXES.md met:
   - Lijst van alle gevonden bugs
   - Voor elke bug: beschrijving, oorzaak, oplossing, test aanpak
   - Welke debugging tools je hebt gebruikt
   - Eventuele verbeteringen die je zou suggereren
3. Clear commit history waarin je proces zichtbaar is

## ⚠️ Extra Uitdaging (optioneel)

Als je klaar bent met de bugs:
- Voeg automatische tests toe om herhaling te voorkomen
- Implementeer caching voor betere performance
- Voeg input validation toe waar nodig
- Implementeer proper error handling

Veel succes met het debuggen! 🔍
