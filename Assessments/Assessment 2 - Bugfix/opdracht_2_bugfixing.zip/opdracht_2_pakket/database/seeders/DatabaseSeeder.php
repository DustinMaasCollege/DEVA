<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Verwijder bestaande test user als die er al is
        User::where('email', 'jd@maascollege.nl')->delete();

        // Maak test user aan
        User::create([
            'name' => 'John Doe',
            'email' => 'jd@maascollege.nl',
            'password' => Hash::make('MijnDevelopmentOpdracht0@!'),
            'email_verified_at' => now(),
        ]);

        $this->command->info('✅ Test gebruiker aangemaakt:');
        $this->command->info('   Email: jd@maascollege.nl');
        $this->command->info('   Wachtwoord: MijnDevelopmentOpdracht0@!');
    }
}
