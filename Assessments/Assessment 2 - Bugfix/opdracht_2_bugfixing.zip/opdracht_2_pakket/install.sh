#!/bin/bash

echo "================================"
echo "Laravel 12 Installatie Script"
echo "================================"
echo ""

# Kleuren voor output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if composer is installed
if ! command -v composer &> /dev/null; then
    echo -e "${RED}❌ Composer is niet geïnstalleerd. Installeer eerst Composer: https://getcomposer.org/${NC}"
    exit 1
fi

echo -e "${YELLOW}📦 Stap 1: Composer dependencies installeren...${NC}"
composer install --no-interaction

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Composer install gefaald${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Composer dependencies geïnstalleerd${NC}"
echo ""

echo -e "${YELLOW}🔑 Stap 2: .env bestand aanmaken...${NC}"
if [ ! -f .env ]; then
    cp .env.example .env
    echo -e "${GREEN}✅ .env bestand aangemaakt${NC}"
else
    echo -e "${YELLOW}⚠️  .env bestaat al, overslaan...${NC}"
fi
echo ""

echo -e "${YELLOW}🔐 Stap 3: Application key genereren...${NC}"
php artisan key:generate
echo -e "${GREEN}✅ Application key gegenereerd${NC}"
echo ""

echo -e "${YELLOW}💾 Stap 4: Database aanmaken en migreren...${NC}"
echo "⚠️  Zorg dat je database credentials in .env correct zijn ingesteld!"
read -p "Druk op Enter om door te gaan met migratie..."

php artisan migrate --force

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Migratie gefaald. Check je database instellingen in .env${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Database migraties uitgevoerd${NC}"
echo ""

echo -e "${YELLOW}🌱 Stap 5: Database seeden met testdata...${NC}"
php artisan db:seed --force

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Seeding gefaald${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Database geseeded${NC}"
echo ""

echo -e "${YELLOW}🎨 Stap 6: NPM dependencies installeren en Tailwind compileren...${NC}"

if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ NPM is niet geïnstalleerd. Installeer eerst Node.js: https://nodejs.org/${NC}"
    exit 1
fi

npm install

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ NPM install gefaald${NC}"
    exit 1
fi

echo -e "${GREEN}✅ NPM dependencies geïnstalleerd${NC}"

npm run build

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Tailwind build gefaald${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Tailwind CSS gecompileerd${NC}"
echo ""

echo -e "${YELLOW}🔒 Stap 7: Storage linken...${NC}"
php artisan storage:link
echo -e "${GREEN}✅ Storage gelinkt${NC}"
echo ""

echo "================================"
echo -e "${GREEN}✅ Installatie voltooid!${NC}"
echo "================================"
echo ""
echo "📋 Inloggegevens:"
echo "   Email: jd@maascollege.nl"
echo "   Wachtwoord: MijnDevelopmentOpdracht0@!"
echo ""
echo "🚀 Start de applicatie met:"
echo "   php artisan serve"
echo ""
echo "🌐 Open daarna in je browser:"
echo "   http://localhost:8000"
echo ""
