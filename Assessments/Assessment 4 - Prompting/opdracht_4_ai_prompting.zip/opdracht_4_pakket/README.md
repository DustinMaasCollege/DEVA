# Laravel 12 Sollicitatie Opdracht - Starter Pakket

Dit is een vooraf geconfigureerd Laravel 12 starter pakket voor je sollicitatie opdracht bij Maas College.

## 📋 Wat zit er in dit pakket?

- ✅ Laravel 12 (nieuwste versie)
- ✅ Tailwind CSS 3.4 (volledig geconfigureerd)
- ✅ 3 vooraf gemaakte pagina's (Home, Over Ons, Belangrijke Gegevens)
- ✅ Authentication systeem (login/logout)
- ✅ Test gebruiker (John Doe)
- ✅ Database migrations
- ✅ Responsive layout
- ✅ Automatisch installatie script

## 🚀 Snelle Start

### Vereisten

Zorg dat je het volgende hebt geïnstalleerd:
- PHP 8.2 of hoger
- Composer
- Node.js & NPM
- MySQL/MariaDB (of andere database)

### Installatie

1. **Pak het project uit** in je gewenste directory

2. **Configureer je database**
   - Open `.env.example` 
   - Pas de database instellingen aan:
     ```
     DB_DATABASE=laravel_opdracht
     DB_USERNAME=root
     DB_PASSWORD=jouw_wachtwoord
     ```
   - Maak de database aan in MySQL:
     ```sql
     CREATE DATABASE laravel_opdracht;
     ```

3. **Voer het installatie script uit**
   
   **Op Linux/Mac:**
   ```bash
   chmod +x install.sh
   ./install.sh
   ```
   
   **Op Windows:**
   ```bash
   bash install.sh
   ```
   
   Of handmatig:
   ```bash
   composer install
   cp .env.example .env
   php artisan key:generate
   php artisan migrate
   php artisan db:seed
   npm install
   npm run build
   ```

4. **Start de applicatie**
   ```bash
   php artisan serve
   ```

5. **Open in browser**
   - Ga naar: http://localhost:8000
   - Login met:
     - Email: `jd@maascollege.nl`
     - Wachtwoord: `MijnDevelopmentOpdracht0@!`

## 📁 Bestandsstructuur

```
project/
├── app/
│   ├── Http/
│   │   └── Controllers/
│   │       └── Auth/
│   │           └── AuthenticatedSessionController.php
│   └── Models/
│       └── User.php
├── database/
│   ├── migrations/
│   │   └── 0001_01_01_000000_create_users_table.php
│   └── seeders/
│       └── DatabaseSeeder.php
├── resources/
│   ├── css/
│   │   └── app.css (Tailwind)
│   ├── js/
│   │   ├── app.js
│   │   └── bootstrap.js
│   └── views/
│       ├── layouts/
│       │   └── app.blade.php (Main template)
│       ├── auth/
│       │   └── login.blade.php
│       ├── home.blade.php
│       ├── about.blade.php
│       └── data.blade.php
├── routes/
│   └── web.php
├── .env.example
├── install.sh (Automatisch installatie script)
├── package.json
├── tailwind.config.js
└── vite.config.js
```

## 🎨 Beschikbare Pagina's

1. **Home** (`/` of `/home`) - Welkomstpagina met introductie
2. **Over Ons** (`/over-ons`) - Informatie over Maas College
3. **Belangrijke Gegevens** (`/belangrijke-gegevens`) - Beveiligde pagina met statistieken

## 👤 Test Gebruiker

Er is automatisch een test gebruiker aangemaakt:
- **Naam:** John Doe
- **Email:** jd@maascollege.nl
- **Wachtwoord:** MijnDevelopmentOpdracht0@!

## 🔒 Beveiliging

Dit pakket is vooraf geconfigureerd met:
- CSRF protection op alle forms
- Password hashing met bcrypt
- Session management
- XSS protection via Blade templating
- SQL injection protection via Eloquent ORM

## 🛠️ Development

### Frontend Development
```bash
# Development mode (met hot reload)
npm run dev

# Production build
npm run build
```

### Database
```bash
# Nieuwe migration maken
php artisan make:migration create_table_name

# Migraties uitvoeren
php artisan migrate

# Database opnieuw opbouwen
php artisan migrate:fresh --seed
```

### Code Style
```bash
# Laravel Pint (code formatter)
./vendor/bin/pint
```

## 📝 Tips voor je Opdracht

1. **Git gebruiken:** Commit regelmatig je werk
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   ```

2. **Documenteer je werk:** Voeg comments toe aan complexe code

3. **Test je code:** Probeer edge cases

4. **Gebruik Laravel's features:**
   - Middleware voor authorization
   - Policies voor fine-grained permissions
   - Service classes voor business logic
   - Form Requests voor validation

5. **Tailwind CSS utility classes:** Gebruik de Tailwind documentatie (https://tailwindcss.com)

## 🐛 Problemen Oplossen

### "Composer not found"
Installeer Composer: https://getcomposer.org

### "NPM not found"
Installeer Node.js: https://nodejs.org

### "SQLSTATE connection refused"
- Check of je database server draait
- Verifieer je `.env` database credentials
- Zorg dat de database bestaat

### "Vite manifest not found"
Voer `npm run build` uit

### "419 Page Expired"
- Clear je browser cache
- Refresh de pagina
- Check of `@csrf` in je forms staat

## 📚 Nuttige Links

- [Laravel Documentatie](https://laravel.com/docs)
- [Tailwind CSS Documentatie](https://tailwindcss.com/docs)
- [Laravel Breeze (voor referentie)](https://laravel.com/docs/starter-kits#breeze)
- [Eloquent ORM](https://laravel.com/docs/eloquent)

## 📞 Hulp Nodig?

Als je vastloopt tijdens de installatie:
1. Check de foutmeldingen zorgvuldig
2. Gebruik Stack Overflow of Laravel forums
3. Gebruik AI-tools zoals ChatGPT, Claude of Cursor voor debugging

## ✅ Checklist voor Inleveren

- [ ] Code werkt lokaal
- [ ] Git repository met clear commit history
- [ ] README.md met uitleg over je aanpak
- [ ] Alle requirements van de opdracht zijn voldaan
- [ ] Code is gedocumenteerd
- [ ] `.env.example` is bijgewerkt (indien nodig)

Veel succes met je opdracht! 🚀
