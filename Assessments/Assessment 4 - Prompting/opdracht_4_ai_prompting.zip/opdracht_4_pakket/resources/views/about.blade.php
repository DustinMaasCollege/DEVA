@extends('layouts.app')

@section('title', 'Over Ons')

@section('content')
<div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
    <div class="p-6">
        <h1 class="text-3xl font-bold text-gray-900 mb-6">
            Over Maas College
        </h1>
        
        <div class="prose max-w-none">
            <div class="mb-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-4">Wie zijn wij?</h2>
                <p class="text-gray-700 mb-4">
                    Maas College is een vooraanstaande onderwijsinstelling die zich richt op het bieden van 
                    hoogwaardig onderwijs en het voorbereiden van studenten op een succesvolle toekomst in 
                    de moderne arbeidsmarkt.
                </p>
                <p class="text-gray-700 mb-4">
                    Met een focus op innovatie en persoonlijke ontwikkeling, bieden wij een breed scala aan 
                    opleidingen aan waarin we modernste technologieën en methodieken inzetten.
                </p>
            </div>

            <div class="mb-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-4">Onze Visie</h2>
                <p class="text-gray-700 mb-4">
                    Wij geloven in de kracht van onderwijs om levens te transformeren. Door gebruik te maken 
                    van moderne technologieën zoals Laravel, Tailwind CSS, en andere cutting-edge tools, 
                    bereiden we onze studenten voor op de uitdagingen van morgen.
                </p>
            </div>

            <div class="grid md:grid-cols-2 gap-6 mb-8">
                <div class="bg-blue-50 p-6 rounded-lg">
                    <h3 class="font-semibold text-lg mb-3 text-gray-900">💡 Innovatie</h3>
                    <p class="text-gray-700 text-sm">
                        We blijven voorop lopen door constant te innoveren en nieuwe technologieën 
                        te omarmen in ons onderwijs.
                    </p>
                </div>

                <div class="bg-green-50 p-6 rounded-lg">
                    <h3 class="font-semibold text-lg mb-3 text-gray-900">🎓 Kwaliteit</h3>
                    <p class="text-gray-700 text-sm">
                        Hoogwaardige docenten en moderne faciliteiten zorgen voor optimale 
                        leeromstandigheden.
                    </p>
                </div>

                <div class="bg-purple-50 p-6 rounded-lg">
                    <h3 class="font-semibold text-lg mb-3 text-gray-900">🤝 Samenwerking</h3>
                    <p class="text-gray-700 text-sm">
                        We werken nauw samen met het bedrijfsleven om studenten de beste 
                        kansen te bieden.
                    </p>
                </div>

                <div class="bg-yellow-50 p-6 rounded-lg">
                    <h3 class="font-semibold text-lg mb-3 text-gray-900">🌟 Persoonlijke Ontwikkeling</h3>
                    <p class="text-gray-700 text-sm">
                        Elke student krijgt persoonlijke begeleiding om hun potentieel volledig 
                        te benutten.
                    </p>
                </div>
            </div>

            <div class="bg-gray-50 border-l-4 border-gray-500 p-6">
                <h3 class="font-semibold text-lg mb-2 text-gray-900">📍 Contact</h3>
                <p class="text-gray-700 text-sm mb-2">
                    <strong>Adres:</strong> Voorbeeldstraat 123, 1234 AB Maastricht
                </p>
                <p class="text-gray-700 text-sm mb-2">
                    <strong>Email:</strong> info@maascollege.nl
                </p>
                <p class="text-gray-700 text-sm">
                    <strong>Telefoon:</strong> +31 (0)43 123 4567
                </p>
            </div>
        </div>
    </div>
</div>
@endsection
