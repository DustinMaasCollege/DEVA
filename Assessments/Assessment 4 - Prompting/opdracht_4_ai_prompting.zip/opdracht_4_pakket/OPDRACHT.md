# Opdracht 4: How to Prompt (AI-Assisted Development) - Starter Pakket

## 🎯 Jouw Opdracht

Laat zien hoe je AI-tools effectief kunt inzetten bij softwareontwikkeling, en toon je kritische blik door gegenereerde code te beoordelen en verbeteren.

### Wat moet je doen?

1. **Gebruik AI om code te genereren** voor één van de voorgestelde features
2. **Beoordeel de gegenereerde code kritisch** op functionaliteit, kwaliteit, security en performance
3. **Verbeter de code** tot productieklare kwaliteit
4. **Documenteer je proces** inclusief alle prompts en je bevindingen

### Wat zit er al in dit pakket?

- ✅ Laravel 12 volledig werkend
- ✅ Tailwind CSS geconfigureerd
- ✅ 3 basis pagina's
- ✅ Basic authentication
- ✅ Clean codebase om mee te starten
- ✅ Test gebruiker: jd@maascollege.nl / MijnDevelopmentOpdracht0@!

## 🚀 Aan de slag

1. Volg de installatie instructies in README.md
2. Kies één van de features hieronder
3. Gebruik je favoriete AI-tool (ChatGPT, Claude, Cursor, GitHub Copilot, etc.)
4. Laat AI de feature voor je bouwen
5. Beoordeel en verbeter de code

## 🎨 Kies één Feature

### Feature A: Two-Factor Authentication (2FA)
Implementeer 2FA via email of authenticator app:
- Gebruiker kan 2FA inschakelen/uitschakelen
- Bij login wordt 2FA code gevraagd
- Backup codes voor noodgevallen

### Feature B: File Upload met Processing
Bouw een upload systeem:
- Gebruikers kunnen bestanden uploaden
- Validatie op bestandstype en grootte
- Processing (bijv: image resize, PDF indexeren)
- Opslag en download functionaliteit

### Feature C: Geavanceerde Zoekfunctie
Implementeer zoeken met filters:
- Zoekbalk met live search (optioneel)
- Filters (categorie, datum, status)
- Sorting en pagination
- Resultaten weergave

## 📝 Fase 1: AI-Assisted Development (~2 uur)

### Je prompt strategie

Documenteer ALLE prompts die je gebruikt. Bijvoorbeeld:

```markdown
## Prompt 1: Initial Setup
**Doel:** Krijg een basis structuur voor 2FA implementatie
**Prompt:** 
"I'm building a 2FA system in Laravel 12. I need:
- A migration to add 2fa fields to users table
- A settings page where users can enable/disable 2FA
- Email-based verification codes
Show me the migration and controller structure."

**Resultaat:** [beschrijf wat je kreeg]
**Evaluatie:** [wat was goed? Wat ontbrak?]
```

### Tips voor effectieve prompts

**DO:**
- ✅ Wees specifiek over context (Laravel 12, bestaande structuur)
- ✅ Vraag om uitleg bij complexe code
- ✅ Vraag om alternatieven en trade-offs
- ✅ Splits complexe problemen op
- ✅ Geef feedback en vraag om verbeteringen

**DON'T:**
- ❌ Vraag niet om "alles in één keer"
- ❌ Accepteer code niet blindelings
- ❌ Vergeet niet om edge cases te benoemen
- ❌ Neem geen verouderde packages aan

## 🔍 Fase 2: Code Assessment (~1.5 uur)

Beoordeel de AI-gegenereerde code op:

### 1. Functionaliteit
- [ ] Werkt de code zoals bedoeld?
- [ ] Zijn alle requirements geïmplementeerd?
- [ ] Worden edge cases afgehandeld?
- [ ] Is error handling aanwezig?

### 2. Code Kwaliteit
- [ ] Volgt de code Laravel conventions?
- [ ] Is de code leesbaar en maintainable?
- [ ] Is er code duplication?
- [ ] Zijn variabelen en functies duidelijk benoemd?
- [ ] Is de code structure logisch?

### 3. Security
- [ ] SQL injection bescherming (gebruik van Eloquent/Query Builder)?
- [ ] XSS bescherming (gebruik van Blade templating)?
- [ ] CSRF protection op forms?
- [ ] Input validation aanwezig?
- [ ] Authorization checks (wie mag wat)?
- [ ] Geen hardcoded secrets/credentials?

### 4. Performance
- [ ] Geen N+1 query problemen?
- [ ] Efficient gebruik van database indexes?
- [ ] Caching waar mogelijk?
- [ ] Lazy vs eager loading correct toegepast?

### 5. Testing
- [ ] Is de code testbaar (geen tight coupling)?
- [ ] Zijn er unit tests meegeleverd?
- [ ] Welke edge cases moeten getest worden?

### Maak een assessment rapport

Voor elk gevonden probleem:
```markdown
### Issue #1: Missing Input Validation
**Severity:** High
**Category:** Security
**Description:** 
The upload controller doesn't validate file types, allowing 
potentially dangerous files to be uploaded.

**Location:** 
app/Http/Controllers/UploadController.php, line 23

**Code:**
```php
public function store(Request $request)
{
    $file = $request->file('upload');
    $file->store('uploads');
}
```

**Recommended Fix:**
Add validation rules with proper mime types and file size limits.
```

## 🛠️ Fase 3: Refactoring (~30 min)

Verbeter de code:

1. **Fix security issues** (hoogste prioriteit!)
2. **Optimize performance** (database queries, caching)
3. **Improve code organization** (MVC pattern, service classes)
4. **Add proper validation**
5. **Add comments where needed**
6. **Follow Laravel conventions**

### Git Workflow

```bash
# Maak twee branches
git checkout -b ai-generated    # Originele AI code
git add .
git commit -m "feat: initial AI-generated 2FA implementation"

git checkout -b main            # Jouw verbeterde versie
# ... maak je improvements ...
git commit -m "fix: add input validation to 2FA setup"
git commit -m "refactor: move business logic to service class"
git commit -m "perf: add caching for 2FA settings"
```

## ✅ Wat verwachten we?

### 1. Prompt Log (`prompts.md`)
```markdown
# AI Prompts Log - 2FA Feature

## Prompt 1: Feature Planning
[prompt text]
- Tool used: ChatGPT 4
- Result: [wat kreeg je?]
- Next steps: [wat deed je hiermee?]

## Prompt 2: Implementation Details
...
```

### 2. Code Assessment Report (`assessment.md`)
- Overzicht van alle issues (gesorteerd op severity)
- Per issue: beschrijving, locatie, impact, aanbevolen oplossing
- Overall conclusie over AI-gegenereerde code

### 3. GitHub Repository
- `ai-generated` branch: Originele code
- `main` branch: Jouw verbeterde versie
- Clear commit messages
- README.md met overzicht

### 4. Reflection Document
- Welke AI tool(s) heb je gebruikt en waarom?
- Wat deed de AI goed?
- Waar schoot de AI tekort?
- Welke prompting technieken werkten het beste?
- Je algemene conclusie over AI-assisted development
- Best practices die je hieruit hebt geleerd

## 🎓 Resources

### Prompting Techniques
- Be specific about context and requirements
- Use iterative refinement (start broad, then narrow)
- Ask for explanations and alternatives
- Request tests and documentation
- Give feedback on output

### Laravel Best Practices
- [Laravel Documentation](https://laravel.com/docs)
- [Laravel Best Practices](https://github.com/alexeymezenin/laravel-best-practices)
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)

### AI Tools
- ChatGPT / Claude: Voor plannen en code generatie
- Cursor: Voor in-editor AI assistance
- GitHub Copilot: Voor code completion

## 📤 Inleveren

GitHub repository met:
- `ai-generated` branch (originele AI code, bewaar dit!)
- `main` branch (jouw verbeterde versie)
- `prompts.md` (alle prompts met reflectie)
- `assessment.md` (code assessment rapport)
- `README.md` (overzicht, gebruikte tools, conclusies)
- Duidelijke commit history

## ⚠️ Veelvoorkomende AI Code Issues

Let op deze rode vlaggen:

🚩 **Security:**
- Geen input validation
- Hardcoded credentials
- Missing authorization checks
- SQL queries met string concatenation

🚩 **Code Quality:**
- Over-engineered solutions
- Inconsistent naming
- Missing error handling
- Deprecated methods/syntax

🚩 **Performance:**
- N+1 query problems
- No caching strategy
- Inefficient algorithms
- Loading more data than needed

🚩 **Testing:**
- No tests provided
- Untestable code (tight coupling)
- Missing edge case coverage

## 💡 Pro Tips

1. **Itereer met AI:** Als de eerste poging niet perfect is, geef specifieke feedback
2. **Vraag om alternatieven:** "What are the pros/cons of this approach?"
3. **Vraag om tests:** "Can you write unit tests for this?"
4. **Check dependencies:** Zorg dat packages up-to-date en compatible zijn
5. **Vertrouw niet blindelings:** AI kan overtuigend klinken maar fout zijn

Succes! Laat zien dat je AI slim kunt inzetten én kritisch blijft! 🤖🧠
