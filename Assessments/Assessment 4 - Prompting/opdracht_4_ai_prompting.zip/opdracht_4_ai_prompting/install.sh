#!/bin/bash

echo "================================"
echo "Laravel 12 Installatie Script"
echo "================================"
echo ""

# Kleuren voor output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if artisan file exists
if [ ! -f artisan ]; then
    echo -e "${RED}❌ artisan bestand niet gevonden. Zorg dat je in de Laravel root directory bent.${NC}"
    exit 1
fi

# Check if composer is installed
if ! command -v composer &> /dev/null; then
    echo -e "${RED}❌ Composer is niet geïnstalleerd. Installeer eerst Composer: https://getcomposer.org/${NC}"
    exit 1
fi

echo -e "${YELLOW}📦 Stap 1: Composer dependencies installeren...${NC}"
if ! composer install --no-interaction; then
    echo -e "${RED}❌ Composer install gefaald${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Composer dependencies geïnstalleerd${NC}"
echo ""

echo -e "${YELLOW}🔑 Stap 2: .env bestand aanmaken...${NC}"
if [ -f .env ]; then
    echo -e "${YELLOW}⚠️  .env bestaat al, overslaan...${NC}"
elif [ -f .env.example ]; then
    cp .env.example .env
    echo -e "${GREEN}✅ .env bestand aangemaakt${NC}"
else
    echo -e "${RED}❌ Noch .env noch .env.example gevonden. Kan niet doorgaan.${NC}"
    exit 1
fi
echo ""

echo -e "${YELLOW}🔐 Stap 3: Application key genereren...${NC}"
if ! php artisan key:generate; then
    echo -e "${RED}❌ Key generatie gefaald${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Application key gegenereerd${NC}"
echo ""

echo -e "${YELLOW}📦 Stap 4: Composer autoload optimaliseren...${NC}"
if ! composer dump-autoload -o; then
    echo -e "${RED}❌ Autoload dump gefaald${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Autoload gegenereerd${NC}"
echo ""

echo -e "${YELLOW}⚙️  Stap 5: Laravel configuratie publiceren...${NC}"
if ! php artisan config:publish --all --quiet; then
    echo -e "${RED}❌ Config publicatie gefaald${NC}"
    exit 1
fi
echo -e "${GREEN}✅ Configuratie bestanden gepubliceerd${NC}"
echo ""

echo -e "${YELLOW}🔒 Stap 6: Permissions instellen...${NC}"
chmod -R 775 storage bootstrap/cache 2>/dev/null || chmod -R 755 storage bootstrap/cache
echo -e "${GREEN}✅ Permissions ingesteld${NC}"
echo ""

echo -e "${YELLOW}💾 Stap 7: Database aanmaken en migreren...${NC}"
echo "⚠️  Zorg dat je database credentials in .env correct zijn ingesteld!"
read -p "Druk op Enter om door te gaan met migratie..."

php artisan migrate --force

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Migratie gefaald. Check je database instellingen in .env${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Database migraties uitgevoerd${NC}"
echo ""

echo -e "${YELLOW}🌱 Stap 8: Database seeden met testdata...${NC}"
php artisan db:seed --force

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Seeding gefaald${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Database geseeded${NC}"
echo ""

echo -e "${YELLOW}🎨 Stap 9: NPM dependencies installeren en Tailwind compileren...${NC}"

if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ NPM is niet geïnstalleerd. Installeer eerst Node.js: https://nodejs.org/${NC}"
    exit 1
fi

npm install

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ NPM install gefaald${NC}"
    exit 1
fi

echo -e "${GREEN}✅ NPM dependencies geïnstalleerd${NC}"

npm run build

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Tailwind build gefaald${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Tailwind CSS gecompileerd${NC}"
echo ""

echo -e "${YELLOW}🔗 Stap 10: Storage linken...${NC}"
php artisan storage:link
echo -e "${GREEN}✅ Storage gelinkt${NC}"
echo ""

echo "================================"
echo -e "${GREEN}✅ Installatie voltooid!${NC}"
echo "================================"
echo ""
echo "📋 Inloggegevens:"
echo "   Email: jd@maascollege.nl"
echo "   Wachtwoord: MijnDevelopmentOpdracht0@!"
echo ""
echo "🚀 Start de applicatie met:"
echo "   php artisan serve"
echo ""
echo "🌐 Open daarna in je browser:"
echo "   http://localhost:8000"
echo ""
