<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Catalogus>
 */
class CatalogusFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $faker = \Faker\Factory::create('nl_NL');

        $categories = ['Elektronica', 'Kleding', 'Boeken', 'Sport', 'Speelgoed', 'Huishouden', 'Tuin', 'Keuken'];

        $products = [
            'Elektronica' => ['Laptop', 'Smartphone', 'Tablet', 'Koptelefoon', 'Smartwatch', 'Camera', 'Monitor', 'Toetsenbord'],
            'Kleding' => ['T-shirt', 'Broek', 'Jas', 'Schoenen', 'Jurk', 'Trui', 'Sokken', 'Pet'],
            'Boeken' => ['Roman', 'Thriller', 'Kookboek', 'Biografie', 'Studieboek', 'Stripboek', 'Magazine', 'Woordenboek'],
            'Sport' => ['Voetbal', 'Fiets', 'Loopschoenen', 'Yogamat', 'Dumbbell', 'Tennisracket', 'Zwembroek', 'Sporttas'],
            'Speelgoed' => ['Lego', 'Puzzel', 'Knuffel', 'Barbiedoll', 'RC Auto', 'Bordspel', 'Actiefiguur', 'Bouwblokken'],
            'Huishouden' => ['Stofzuiger', 'Lamp', 'Kussen', 'Dekbed', 'Handdoek', 'Spiegel', 'Prullenbak', 'Kast'],
            'Tuin' => ['Tuinset', 'Grasmaaier', 'Bloempot', 'Tuinslang', 'BBQ', 'Parasol', 'Schep', 'Plantenbak'],
            'Keuken' => ['Koffiezetapparaat', 'Blender', 'Pannenset', 'Bestek', 'Borden', 'Glazen', 'Mes', 'Snijplank'],
        ];

        $category = $faker->randomElement($categories);
        $productType = $faker->randomElement($products[$category]);
        $brand = $faker->randomElement(['Premium', 'Deluxe', 'Pro', 'Basic', 'Elite', 'Classic', 'Modern']);

        $sku = strtoupper($faker->unique()->bothify('??-####-??'));

        return [
            'naam' => $brand . ' ' . $productType,
            'beschrijving' => $faker->paragraph(3),
            'prijs' => $faker->randomFloat(2, 9.99, 999.99),
            'categorie' => $category,
            'voorraad' => $faker->numberBetween(0, 200),
            'sku' => $sku,
            'afbeelding' => 'https://picsum.photos/seed/' . $sku . '/400/300',
            'actief' => $faker->boolean(90),
        ];
    }
}
