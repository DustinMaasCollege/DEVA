<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
    <div class="p-6">
        <h1 class="text-3xl font-bold text-gray-900 mb-4">
            Welkom bij de Sollicitatie Opdracht
        </h1>
        
        <div class="prose max-w-none">
            <p class="text-gray-700 mb-4">
                Dit is de startpagina van je Laravel opdracht. Deze applicatie is voorgeconfigureerd met:
            </p>

            <ul class="list-disc list-inside space-y-2 text-gray-700 mb-6">
                <li>Laravel 12 - Het nieuwste framework</li>
                <li>Tailwind CSS - Voor moderne styling</li>
                <li>Database migrations - Klaar voor gebruik</li>
                <li>Authentication - Basis setup aanwezig</li>
                <li>Responsive layout - Werkt op alle apparaten</li>
            </ul>

            <div class="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-blue-700">
                            <strong>Test account:</strong><br>
                            Email: jd@maascollege.nl<br>
                            Wachtwoord: MijnDevelopmentOpdracht0@!
                        </p>
                    </div>
                </div>
            </div>

            <div class="grid md:grid-cols-3 gap-6 mt-8">
                <div class="bg-gray-50 p-6 rounded-lg">
                    <h3 class="font-semibold text-lg mb-2 text-gray-900">📚 Documentatie</h3>
                    <p class="text-gray-600 text-sm">
                        Laravel biedt uitgebreide documentatie voor alle functionaliteiten.
                    </p>
                </div>

                <div class="bg-gray-50 p-6 rounded-lg">
                    <h3 class="font-semibold text-lg mb-2 text-gray-900">🎨 Tailwind CSS</h3>
                    <p class="text-gray-600 text-sm">
                        Gebruik utility classes voor snelle en consistente styling.
                    </p>
                </div>

                <div class="bg-gray-50 p-6 rounded-lg">
                    <h3 class="font-semibold text-lg mb-2 text-gray-900">🚀 Klaar om te starten</h3>
                    <p class="text-gray-600 text-sm">
                        Begin met het uitwerken van je opdracht. Succes!
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(auth()->guard()->check()): ?>
<div class="mt-6 bg-green-50 border border-green-200 rounded-lg p-6">
    <h2 class="text-xl font-semibold text-green-900 mb-2">
        ✅ Je bent ingelogd als <?php echo e(Auth::user()->name); ?>

    </h2>
    <p class="text-green-700">
        Je kunt nu beginnen met het uitwerken van je opdracht.
    </p>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/beijersbergen/Downloads/opdracht_4_pakket/resources/views/home.blade.php ENDPATH**/ ?>