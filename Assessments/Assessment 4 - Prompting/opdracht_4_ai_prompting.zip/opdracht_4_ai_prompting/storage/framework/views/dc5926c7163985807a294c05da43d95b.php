<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?> - <?php echo $__env->yieldContent('title', 'Home'); ?></title>

    <!-- Tailwind CSS -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex">
                    <div class="flex-shrink-0 flex items-center">
                        <a href="<?php echo e(route('home')); ?>" class="text-2xl font-bold text-blue-600">
                            <?php echo e(config('app.name', 'Laravel')); ?>

                        </a>
                    </div>
                    <div class="hidden sm:ml-6 sm:flex sm:space-x-8">
                        <a href="<?php echo e(route('home')); ?>" 
                           class="<?php if(request()->routeIs('home')): ?> border-blue-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                            Home
                        </a>
                        <a href="<?php echo e(route('about')); ?>"
                           class="<?php if(request()->routeIs('about')): ?> border-blue-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                            Over Ons
                        </a>
                        <a href="<?php echo e(route('catalogus')); ?>"
                           class="<?php if(request()->routeIs('catalogus')): ?> border-blue-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                            Catalogus
                        </a>
                        <a href="<?php echo e(route('data')); ?>"
                           class="<?php if(request()->routeIs('data')): ?> border-blue-500 text-gray-900 <?php else: ?> border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 <?php endif; ?> inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                            Belangrijke Gegevens
                        </a>
                    </div>
                </div>
                <div class="flex items-center">
                    <?php if(auth()->guard()->check()): ?>
                        <div class="flex items-center space-x-4">
                            <span class="text-sm text-gray-700"><?php echo e(Auth::user()->name); ?></span>
                            <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="text-sm text-gray-500 hover:text-gray-700">
                                    Uitloggen
                                </button>
                            </form>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 hover:text-gray-900">
                            Inloggen
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Mobile menu -->
        <div class="sm:hidden">
            <div class="pt-2 pb-3 space-y-1">
                <a href="<?php echo e(route('home')); ?>" 
                   class="<?php if(request()->routeIs('home')): ?> bg-blue-50 border-blue-500 text-blue-700 <?php else: ?> border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 <?php endif; ?> block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
                    Home
                </a>
                <a href="<?php echo e(route('about')); ?>"
                   class="<?php if(request()->routeIs('about')): ?> bg-blue-50 border-blue-500 text-blue-700 <?php else: ?> border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 <?php endif; ?> block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
                    Over Ons
                </a>
                <a href="<?php echo e(route('catalogus')); ?>"
                   class="<?php if(request()->routeIs('catalogus')): ?> bg-blue-50 border-blue-500 text-blue-700 <?php else: ?> border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 <?php endif; ?> block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
                    Catalogus
                </a>
                <a href="<?php echo e(route('data')); ?>"
                   class="<?php if(request()->routeIs('data')): ?> bg-blue-50 border-blue-500 text-blue-700 <?php else: ?> border-transparent text-gray-600 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-800 <?php endif; ?> block pl-3 pr-4 py-2 border-l-4 text-base font-medium">
                    Belangrijke Gegevens
                </a>
            </div>
        </div>
    </nav>

    <!-- Page Content -->
    <main class="py-8">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <?php if(session('success')): ?>
                <div class="mb-6 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="mb-6 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                    <span class="block sm:inline"><?php echo e(session('error')); ?></span>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t border-gray-200 mt-12">
        <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
            <p class="text-center text-gray-500 text-sm">
                &copy; <?php echo e(date('Y')); ?> <?php echo e(config('app.name', 'Laravel')); ?>. Sollicitatie Opdracht - Maas College
            </p>
        </div>
    </footer>
</body>
</html>
<?php /**PATH /Users/beijersbergen/Downloads/opdracht_4_pakket/resources/views/layouts/app.blade.php ENDPATH**/ ?>