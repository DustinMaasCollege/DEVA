<?php $__env->startSection('title', 'Catalogus'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-8">
    <h1 class="text-3xl font-bold text-gray-900">Productcatalogus</h1>
    <p class="mt-2 text-gray-600">Bekijk ons volledige assortiment van <?php echo e($catalogus->total()); ?> producten</p>
</div>

<?php if($catalogus->isEmpty()): ?>
    <div class="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg">
        <p>Er zijn momenteel geen producten beschikbaar in de catalogus.</p>
    </div>
<?php else: ?>
    <!-- Product Grid -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
        <?php $__currentLoopData = $catalogus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <!-- Product Image -->
                <div class="relative h-48 bg-gray-200 overflow-hidden">
                    <img
                        data-src="https://picsum.photos/seed/<?php echo e($product->sku); ?>/400/300"
                        alt="<?php echo e($product->naam); ?>"
                        class="lazy w-full h-full object-cover"
                        loading="lazy"
                    >
                    <?php if($product->voorraad <= 5 && $product->voorraad > 0): ?>
                        <span class="absolute top-2 right-2 bg-orange-500 text-white text-xs px-2 py-1 rounded">
                            Laatste stuks
                        </span>
                    <?php elseif($product->voorraad == 0): ?>
                        <span class="absolute top-2 right-2 bg-red-500 text-white text-xs px-2 py-1 rounded">
                            Uitverkocht
                        </span>
                    <?php endif; ?>
                </div>

                <!-- Product Info -->
                <div class="p-4">
                    <!-- Category Badge -->
                    <span class="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mb-2">
                        <?php echo e($product->categorie); ?>

                    </span>

                    <!-- Product Name -->
                    <h3 class="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
                        <?php echo e($product->naam); ?>

                    </h3>

                    <!-- Product Description -->
                    <p class="text-sm text-gray-600 mb-3 line-clamp-3">
                        <?php echo e($product->beschrijving); ?>

                    </p>

                    <!-- Price and Stock -->
                    <div class="flex items-center justify-between mt-4">
                        <div>
                            <span class="text-2xl font-bold text-blue-600">
                                &euro; <?php echo e(number_format($product->prijs, 2, ',', '.')); ?>

                            </span>
                        </div>
                        <div class="text-right">
                            <span class="text-xs text-gray-500">Voorraad:</span>
                            <span class="block text-sm font-medium <?php echo e($product->voorraad > 10 ? 'text-green-600' : ($product->voorraad > 0 ? 'text-orange-600' : 'text-red-600')); ?>">
                                <?php echo e($product->voorraad > 0 ? $product->voorraad . ' stuks' : 'Uitverkocht'); ?>

                            </span>
                        </div>
                    </div>

                    <!-- SKU -->
                    <div class="mt-3 pt-3 border-t border-gray-200">
                        <span class="text-xs text-gray-500">SKU: <?php echo e($product->sku); ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Pagination -->
    <div class="mt-8">
        <?php echo e($catalogus->links()); ?>

    </div>
<?php endif; ?>

<!-- Lazy Loading Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const lazyImages = document.querySelectorAll('img.lazy');

    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                img.classList.add('loaded');
                imageObserver.unobserve(img);
            }
        });
    });

    lazyImages.forEach(image => {
        imageObserver.observe(image);
    });
});
</script>

<!-- Additional Styles for line clamping -->
<style>
    .line-clamp-2 {
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    .line-clamp-3 {
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }

    img.lazy {
        background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
        background-size: 200% 100%;
        animation: loading 1.5s ease-in-out infinite;
    }

    @keyframes loading {
        0% { background-position: 200% 0; }
        100% { background-position: -200% 0; }
    }

    img.loaded {
        animation: fadeIn 0.3s ease-in;
    }

    @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/beijersbergen/Downloads/opdracht_4_pakket/resources/views/catalogus/index.blade.php ENDPATH**/ ?>