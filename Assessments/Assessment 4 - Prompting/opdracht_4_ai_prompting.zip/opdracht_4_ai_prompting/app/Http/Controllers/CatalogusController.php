<?php

namespace App\Http\Controllers;

use App\Models\Catalogus;
use Illuminate\Http\Request;

class CatalogusController extends Controller
{
    public function index()
    {
        $catalogus = Catalogus::where('actief', true)
            ->orderBy('naam')
            ->paginate(10);

        return view('catalogus.index', compact('catalogus'));
    }
}
