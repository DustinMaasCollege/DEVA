<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Catalogus extends Model
{
    /** @use HasFactory<\Database\Factories\CatalogusFactory> */
    use HasFactory;

    protected $table = 'catalogus';

    protected $fillable = [
        'naam',
        'beschrijving',
        'prijs',
        'categorie',
        'voorraad',
        'sku',
        'afbeelding',
        'actief',
    ];

    protected $casts = [
        'prijs' => 'decimal:2',
        'voorraad' => 'integer',
        'actief' => 'boolean',
    ];
}
