<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\CatalogusController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Home pagina
Route::get('/', function () {
    return view('home');
})->name('home');

// Over Ons pagina
Route::get('/over-ons', function () {
    return view('about');
})->name('about');

// Belangrijke Gegevens pagina
Route::get('/belangrijke-gegevens', function () {
    return view('data');
})->name('data');

// Catalogus pagina
Route::get('/catalogus', [CatalogusController::class, 'index'])->name('catalogus');

// Authentication routes
Route::get('/login', [AuthenticatedSessionController::class, 'create'])
    ->name('login')
    ->middleware('guest');

Route::post('/login', [AuthenticatedSessionController::class, 'store'])
    ->middleware('guest');

Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])
    ->name('logout')
    ->middleware('auth');
