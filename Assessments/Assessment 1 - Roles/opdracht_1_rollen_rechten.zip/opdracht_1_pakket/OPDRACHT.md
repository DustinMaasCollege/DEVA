# Opdracht 1: Rollen & Rechten - Starter Pakket

## 🎯 Jouw Opdracht

Ontwerp een eerste opzet voor een rollen- en rechtenstructuur binnen deze Laravel-applicatie.

### Wat moet je doen?

1. Bedenk hoe je een rollen en rechten systeem zou opzetten
2. Implementeer minimaal één centrale functie/methode die bepaalt of een pagina wel of niet getoond mag worden op basis van een rol
3. Kies je eigen aanpak: middleware, policies, service class, of een combinatie

### Wat zit er al in dit pakket?

- ✅ Laravel 12 volledig werkend
- ✅ Tailwind CSS geconfigureerd
- ✅ 3 pagina's: Home, Over Ons, Belangrijke Gegevens
- ✅ Basic authentication (login/logout)
- ✅ Test gebruiker: jd@maascollege.nl / MijnDevelopmentOpdracht0@!

## 🚀 Aan de slag

1. Volg de installatie instructies in README.md
2. Start met nadenken over je architectuur:
   - Welke rollen heb je nodig? (bijv: admin, user, guest)
   - Waar ga je de rol opslaan? (database, enum, config?)
   - Hoe check je de rol? (middleware, policy, helper functie?)

## 💡 Suggesties voor je implementatie

### Optie A: Database-based rollen
```php
// Migration voor roles tabel
Schema::create('roles', function (Blueprint $table) {
    $table->id();
    $table->string('name');
    // ...
});

// User krijgt een role_id
Schema::table('users', function (Blueprint $table) {
    $table->foreignId('role_id')->nullable();
});
```

### Optie B: Middleware aanpak
```php
// app/Http/Middleware/CheckRole.php
public function handle($request, Closure $next, $role)
{
    // Jouw logica hier
}
```

### Optie C: Policy-based
```php
// app/Policies/PagePolicy.php
public function viewPage(User $user, $pageName)
{
    // Jouw logica hier
}
```

## ✅ Wat verwachten we?

Minimaal één van:
- Controller met role-checking logic
- Middleware class
- Service class
- Policy class

Plus:
- Korte toelichting (comments of README) over je keuzes
- Optioneel: migrations/seeds voor roles
- Optioneel: een demo route die je implementatie toont

## 📝 Tips

1. **Denk aan schaalbaarheid:** Hoe voeg je later meer rollen toe?
2. **Denk aan herbruikbaarheid:** Kan je logica op meerdere plekken gebruikt worden?
3. **Documenteer je keuzes:** Waarom kies je voor middleware vs policy vs iets anders?
4. **Test verschillende scenario's:** 
   - Niet ingelogde user
   - Ingelogde user zonder rechten
   - Ingelogde user met rechten

## 🎓 Laravel Referenties

- [Middleware Documentation](https://laravel.com/docs/middleware)
- [Authorization (Gates & Policies)](https://laravel.com/docs/authorization)
- [Database: Migrations](https://laravel.com/docs/migrations)

## 📤 Inleveren

- Git repository met je code
- README.md of SOLUTION.md met:
  - Hoe je het hebt aangepakt
  - Welke keuzes je hebt gemaakt en waarom
  - Hoe je het zou testen
  - Wat je zou doen met meer tijd

Succes! 🚀
